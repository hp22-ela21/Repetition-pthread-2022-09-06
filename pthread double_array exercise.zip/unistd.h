#ifndef UNISTD_H_
#define UNISTD_H_

#ifdef __cplusplus
extern "C"
{
#endif

   /*************************************************************************************
   * Denna headerfil samt motsvarande k�llkodsfil unistd.c utg�r enbart dummyfiler f�r
   * kompilering i Visual Studio. Tag inte med dessa filer vid kompilering i Linuxmilj�.
   **************************************************************************************/

   /* Inkluderingsdirektiv: */
#include <stdlib.h>

   void sleep(const size_t delay_time);
   void usleep(const size_t delay_time);

#ifdef __cplusplus
}
#endif

#endif /* UNISTD_H_ */