/* Inkluderingsdirektiv: */
#include "pthread.h"

/**********************************************************************************************
* F�ljande k�llkodsfil samt motsvarande headerfil pthread.h utg�r dummyfiler f�r
* implementering av flertr�dade program i C via biblioteket pthread. H�r definieras funktioner
* f�r att implementera samt synkronisera tr�dar. Fler definitioner kan l�ggas till vid behov.
*
* Vid kompilering i Linux, implementera ej dessa pthread-filer, utan kompilera med det
* riktiga biblioteket pthread.h genom att l�gga till -l pthread i aktuellt kommando.
* Som exempel, f�r att kompilera samtliga C-filer i en mapp med GCC-kompilatorn och skapa
* en k�rbar fil d�pt main kan f�ljande kommando anv�ndas:
*
* gcc *c -o main -Wall -l pthread
**********************************************************************************************/

/* Funktionsdefinitioner: */
int pthread_create(pthread_t* thread, pthread_attr_t* attr, 
                   void* (*start_routine)(void*), void* arg) { return 0; }
int pthread_join(pthread_t thread, void** ret_val) { return 0; }