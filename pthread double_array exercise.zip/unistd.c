/* Inkluderingsdirektiv: */
#include "unistd.h"

/*************************************************************************************
* Denna k�llkodsfil samt motsvarande headerfil unistd.c utg�r enbart dummyfiler f�r
* kompilering i Visual Studio. Tag inte med dessa filer vid kompilering i Linuxmilj�.
**************************************************************************************/

void sleep(const size_t delay_time) { }
void usleep(const size_t delay_time) { }
