#ifndef PTHREAD_H_
#define PTHREAD_H_

/**********************************************************************************************
* F�ljande headerfil samt motsvarande k�llkodsfil pthread.c utg�r dummyfiler f�r enkel
* implementering av flertr�dade program i C via biblioteket pthread. H�r deklareras funktioner
* f�r att implementera samt synkronisera tr�dar. Fler deklarationer kan l�ggas till vid behov.
* 
* Vid kompilering i Linux, implementera ej dessa pthread-filer, utan kompilera med det
* riktiga biblioteket pthread.h genom att l�gga till -l pthread i aktuellt kommando.
* Som exempel, f�r att kompilera samtliga C-filer i en mapp med GCC-kompilatorn och skapa
* en k�rbar fil d�pt main kan f�ljande kommando anv�ndas:
*
* gcc *c -o main -Wall -l pthread
**********************************************************************************************/

#ifdef __cplusplus
extern "C"
#endif 

/* Typdefinitioner: */
typedef struct { void* dummy; } pthread_t;
typedef struct { void* dummy; } pthread_attr_t;

/* Externa funktioner: */
int pthread_create(pthread_t* thread, pthread_attr_t* attr, 
                   void* (*start_routine)(void*), void* arg);
int pthread_join(pthread_t thread, void** ret_val);

#ifdef __cplusplus
}
#endif

#endif /* PTHREAD_H_ */